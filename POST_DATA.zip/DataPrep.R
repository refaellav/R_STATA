rm(list=ls())

setwd("C:/Documents and Settings/lavre/My Documents/meetup/R and Stata")
list.files(all.files=T)
#data1 <-  read.table("CtyxCty_schl_US.txt", sep="\t", header = F)
#data2 <-  read.table("CtyxCty_ahinc_US.txt", sep="\t", header = F)
data1 <-  read.table("CtyxCty_US.txt", sep="\t", header = F)
##data4 <-  read.table("CtyxCty_apinc_US.txt", sep="\t", header = F)

data1 <- data1[1: 131037, ]

lkup <- read.csv('census_lookup.csv')
lkup$start <- substr(lkup[,2], 1, lapply(lkup[,2],function(x) which(strsplit(as.character(x), "")[[1]]=="-")-1  ))
lkup$end <- substr(lkup[,2], lapply(lkup[,2],function(x) which(strsplit(as.character(x), "")[[1]]=="-")+1), 50  )
lkup2 <- lkup[,3:4]
lkup3 <- lkup2 [5:nrow(lkup2),]
lkup4 <- lkup2 [1:4, ]

lkup3$start <- as.numeric(lkup3$start)#+2
lkup3$end <- as.numeric(lkup3$end)#+2
lkup4$start <- as.numeric(lkup4$start)
lkup4$end <- as.numeric(lkup4$end)
lkup2 <- rbind(lkup4,lkup3)

entry <- NULL
lst <- list()

n <- length(data1)

data5 <- data1 

for (y in 1:length(data5)) {
  for (z in 1:nrow(lkup2)){ 
    entry[z] <- substr(data5[y],  as.numeric(as.character(lkup2[z,1])), as.numeric(as.character(lkup2[z,2])))
  }
  lst[[y]] <- entry
}

 df1 <- data.frame(matrix(unlist(lst), nrow =  131037, byrow = T)) 
 
 n <- lkup[ ,1 ]
 colnames(df1)<- n
 write.csv(df1, "CtyxCty_US_v2.csv")
  ##131037
  
#####
data1 <-  read.table("CtyxCty_schl_US.txt", sep="\t", header = F)  
 data1 <- data1[1:113674, ]

lkup <- read.csv('census_lookup2.csv')
lkup$start <- substr(lkup[,2], 1, lapply(lkup[,2],function(x) which(strsplit(as.character(x), "")[[1]]=="-")-1  ))
lkup$end <- substr(lkup[,2], lapply(lkup[,2],function(x) which(strsplit(as.character(x), "")[[1]]=="-")+1), 50  )
lkup2 <- lkup[,3:4]
lkup3 <- lkup2 [5:nrow(lkup2),]
lkup4 <- lkup2 [1:4, ]

lkup3$start <- as.numeric(lkup3$start)#+2
lkup3$end <- as.numeric(lkup3$end)#+2
lkup4$start <- as.numeric(lkup4$start)
lkup4$end <- as.numeric(lkup4$end)
lkup2 <- rbind(lkup4,lkup3)

entry <- NULL
lst <- list()

n <- length(data1)

data5 <- data1

for (y in 1:length(data5)) {
  for (z in 1:nrow(lkup2)){ 
    entry[z] <- substr(data5[y],  as.numeric(as.character(lkup2[z,1])), as.numeric(as.character(lkup2[z,2])))
  }
  lst[[y]] <- entry
}

 df1 <- data.frame(matrix(unlist(lst), nrow = 113674, byrow = T)) 
 
 n <- lkup[ ,1 ]
 colnames(df1)<- n
 write.csv(df1, "CtyxCty_US_v3.csv")


 
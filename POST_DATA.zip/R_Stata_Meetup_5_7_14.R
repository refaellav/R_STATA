##Clear memory
rm(list=ls())
##Set working directory 
setwd("C:/Documents and Settings/lavre/My Documents/meetup/R and Stata")
#Load data
C_data <- read.csv("CtyxCty_US.csv",header = T)
names(C_data)
C_data <- C_data[ ,c(-1)]
names(C_data)
##Update column names
colnames(C_data) <- c("c_state_fips","c_county_fips","p_state_fips"
,"p_county_fips","c_state","c_county","cc_pop","cc_pop_moe","cc_nonmovers"
,"cc_nonmovers_moe","cc_usmovers","cc_usmovers_moe","cc_samecountymovers"
,"cc_samecountymovers_moe","cc_diffcountymovers","cc_diffcountymovers_moe"
,"cc_diffstatemovers","cc_diffstatemovers_moe","cc_abroadmovers","cc_abroadmovers_moe"
,"p_state","p_county","pc_pop","pc_pop_moe","pc_nonmovers","pc_nonmovers_moe","pc_usmovers"
,"pc_usmovers_moe","pc_samecountymovers","pc_samecountymovers_moe","pc_diffcountymovers"
,"pc_diffcountymovers_moe","pc_abroadmovers","pc_abroadmovers_moe","movers_pr"
,"movers_pr_moe","movers_within","movers_moe" )
##Get data type  in your data set
str(C_data)

## Create Subset where the c_state_fips is 1 (DC)
C_data_1_1 <- subset(C_data, c_state_fips == "11")

#Write new data set out to CSV
write.csv(C_data_1_1, "C_data_1_1.csv")

##Some high level look at the data � examples 
C_data_1 <- C_data[ ,c(1:2)]
head(C_data_1)
# unique of unique
C_data_1_dup_out <- unique(C_data_1[ , 1:2 ] )
head(C_data_1_dup_out)
#Same for previous
C_data_1 <- C_data[ ,c(3:4)]
C_data_1_dup_out2 <- unique(C_data_1[ , 1:2 ] )
head(C_data_1_dup_out2)

## Create Subset where the c_state_fips is 1 (DC) to work on
C_data_DC <- subset(C_data, C_data$c_state_fips == "11" )                                 
C_data_DC <- C_data_DC[ ,c(1:6,21:22,37:38 ) ]
str(C_data_DC)
head(C_data_DC)

#Separating data by columns
c_stats  <- C_data_DC[ ,c(grep("\\bc.", names(C_data_DC))) ]
p_stats  <- C_data_DC[ ,c(grep("\\bp.", names(C_data_DC))) ]
# There are other function such as grep that will bring columns that contain a string 


#Tidy data
library(reshape)
C_data_DC_1<-melt(C_data_DC)


#Basic summary
table (C_data_DC$p_state_fips )
#Graphical representation
plot(table (C_data_DC$p_state_fips ))
#Graphical representation - nicer
library(ggplot2)
# where y to represent values in the data
x <- data.frame (table (C_data_DC$p_state_fips ))
a1 <- qplot(Var1,Freq, data=x, geom="bar", stat="identity")
a1

 #Functions in R - This one provide a data frame for var with Frequency over 15
frq_over<-function(Colm)
{
X<-as.data.frame(table(Colm))
X2<-as.data.frame(subset(X, Freq>15) )
X2
}
#Apply the above function for columns number 9 and 10
apply(C_data_DC[ ,9:10], 2,frq_over)


#Column headers in the DC file
# names(C_data_DC)
# sume density data example 
# dens<-density(C_data_DC$movers_within, na.rm=T)
# plot(dens)


#ok, what about group by? notice the missing valaue element at the end!
aggdata <-aggregate(C_data_DC$movers_within, by=list(C_data_DC$p_state), FUN=sum, na.rm=TRUE) 
aggdata
#Let�s order it in a descending order
aggdata<-aggdata[order(-aggdata$x),]
aggdata
# what is that looks like?
plot(aggdata)

#Whats the bottom 10 lines looks like?
aggdata2 <- aggdata[50:60,] 
#Nicer plot!                                
p <- qplot(Group.1, x, data=aggdata2, size= x ,  color =-x)
p <- p + xlab("Past State")
p <- p + ylab("Count")
p <- p + theme(axis.text.x=element_text(angle=-90))
p <- p + ggtitle("Where are people coming from?") + theme(plot.title = element_text(face="bold"))
p



#Bring together 2 files and generate some analyses
#This data set contain education level
#Educational Attainment Code: 
#(Population 25 years and over) 
#01 = Less than high school graduate 
#02 = High school graduate (includes equivalency) 
#03 = Some college or associate�s degree 
#04 = Bachelor�s degree 
#05 = Graduate or professional degree 



C_data_edu <- read.csv("CtyxCty_schl_US_class.csv",header = T )
  # subset for DC and education level 5 (Master level)
C_data_edu_DC <- subset(C_data_edu, C_data_edu$Current.Residence.State.Code..based.on.FIPS.code..1.3  == "11" & C_data_edu$Educational.Attainment.Code..13.14 =="5" )
#Select a set of columns we deemed relevent
C_data_edu_DC <- C_data_edu_DC [ ,2:12]
# Updated column names similar to our previous data set
colnames(C_data_edu_DC) <- c("c_state_fips","c_county_fips","p_state_fips","p_county_fips","edu","c_state","c_county", "p_state","p_county","movers_within_EDU","movers_moe_EDU" )
 #view our problem
 C_data_DC$p_state_fips
#One way to address if I am looking only for US move 
C_data_DC$p_state_fips <- as.numeric(as.character(C_data_DC$p_state_fips))



C_data_DC_edu_all <- merge(C_data_DC,C_data_edu_DC,by=c("c_state_fips","c_county_fips", "p_state_fips","p_county_fips"),all=TRUE)
C_data_DC_edu_all_FL <- subset(C_data_DC_edu_all, C_data_DC_edu_all$p_state_fips =="12")
C_data_DC_edu_all_FL$ratio <- C_data_DC_edu_all_FL$movers_within_EDU/C_data_DC_edu_all_FL$movers_within
C_data_DC_edu_all_FL

names(C_data_DC_edu_all_FL)
plot(C_data_DC_edu_all_FL$ratio)

#Same ratio but for all states
C_data_DC_edu_all$ratio <- as.numeric(C_data_DC_edu_all$movers_within_EDU/C_data_DC_edu_all$movers_within)
DC <-aggregate(C_data_DC_edu_all$ratio, by=list(C_data_DC_edu_all$p_state.y), FUN=mean, na.rm=TRUE) 
#plot by order
plot(DC)

# lets take a look at top states
DC<-DC[order(-DC$x),] 
DC <- DC[1:5, ]
#Nicer plot!   
p2 <- qplot(Group.1, x , data=DC ,geom="point")
p2 <- p2 + ggtitle("High Level Education Move to DC") + theme(plot.title = element_text(face="bold"))
p2 <- p2 + xlab("State")
p2 <- p2 + ylab("Mean Ratio")
p2 <- p2 + theme(axis.text.x=element_text(angle=-90)) 
p2




